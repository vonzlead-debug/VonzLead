VonzLead Website
================

1. Open index.html in a browser to preview the site.
2. Before publishing, replace:
   - [YOUR BUSINESS EMAIL]
   - [YOUR BUSINESS PHONE]
3. Use the same business name and service description in Stripe.
4. Publish the folder with any static web host you choose.
5. After it is live, give Stripe the full public URL.

Important:
- Stripe says a website used for business promotion/payment should be functioning and accessible, and should include the business name and description of services. Stripe also lists customer-service contact information and refund/dispute/cancellation information as additional website information to provide when selling services.
- This site does not claim guaranteed lead volume or roofing revenue.
